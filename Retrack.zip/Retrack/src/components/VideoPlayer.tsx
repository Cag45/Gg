import { useRef, useState, useEffect, useCallback } from "react";
import { X } from "lucide-react";

interface VideoPlayerProps {
  videoUrl: string;
  episodeName: string;
  onClose: () => void;
}

const formatTime = (seconds: number) => {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
};

const VideoPlayer = ({ videoUrl, episodeName, onClose }: VideoPlayerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [skipAnimation, setSkipAnimation] = useState<"back" | "forward" | null>(null);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekPreviewTime, setSeekPreviewTime] = useState(0);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [seekDotX, setSeekDotX] = useState(0);

  const resetHideTimer = useCallback(() => {
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      if (isPlaying && !isSeeking) setShowControls(false);
    }, 3000);
  }, [isPlaying, isSeeking]);

  const toggleControls = useCallback(() => {
    if (showControls) {
      setShowControls(false);
    } else {
      setShowControls(true);
      resetHideTimer();
    }
  }, [showControls, resetHideTimer]);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play();
      setIsPlaying(true);
    } else {
      v.pause();
      setIsPlaying(false);
    }
    resetHideTimer();
  }, [resetHideTimer]);

  const skip = useCallback((seconds: number) => {
    const v = videoRef.current;
    if (!v) return;
    setSkipAnimation(seconds < 0 ? "back" : "forward");
    v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + seconds));
    setTimeout(() => setSkipAnimation(null), 500);
    resetHideTimer();
  }, [resetHideTimer]);

  const generateThumbnail = useCallback((time: number) => {
    const pv = previewVideoRef.current;
    if (!pv) return;
    pv.currentTime = time;
  }, []);

  useEffect(() => {
    const pv = previewVideoRef.current;
    const canvas = canvasRef.current;
    if (!pv || !canvas) return;
    const onSeeked = () => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      canvas.width = 240;
      canvas.height = 135;
      ctx.drawImage(pv, 0, 0, 240, 135);
      setThumbnailUrl(canvas.toDataURL("image/jpeg", 0.6));
    };
    pv.addEventListener("seeked", onSeeked);
    return () => pv.removeEventListener("seeked", onSeeked);
  }, []);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => setCurrentTime(v.currentTime);
    const onLoaded = () => {
      setDuration(v.duration);
      v.play().then(() => setIsPlaying(true)).catch(() => {});
    };
    const onEnded = () => {
      setIsPlaying(false);
      setShowControls(true);
    };
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("loadedmetadata", onLoaded);
    v.addEventListener("ended", onEnded);
    return () => {
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("loadedmetadata", onLoaded);
      v.removeEventListener("ended", onEnded);
    };
  }, []);

  useEffect(() => {
    if (showControls && isPlaying) resetHideTimer();
    return () => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [showControls, isPlaying, resetHideTimer]);

  const progress = duration ? (currentTime / duration) * 100 : 0;
  const remaining = duration - currentTime;

  const handleProgressInteraction = useCallback((clientX: number) => {
    const bar = progressRef.current;
    if (!bar) return;
    const rect = bar.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    return ratio;
  }, []);

  const handleProgressDown = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    setIsSeeking(true);
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const ratio = handleProgressInteraction(clientX);
    if (ratio !== undefined) {
      setSeekPreviewTime(ratio * duration);
      setSeekDotX(ratio * 100);
      generateThumbnail(ratio * duration);
    }
  }, [duration, handleProgressInteraction, generateThumbnail]);

  const handleProgressMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!isSeeking) return;
    const clientX = "touches" in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
    const ratio = handleProgressInteraction(clientX);
    if (ratio !== undefined) {
      setSeekPreviewTime(ratio * duration);
      setSeekDotX(ratio * 100);
      generateThumbnail(ratio * duration);
    }
  }, [isSeeking, duration, handleProgressInteraction, generateThumbnail]);

  const handleProgressUp = useCallback(() => {
    if (!isSeeking) return;
    setIsSeeking(false);
    setThumbnailUrl(null);
    const v = videoRef.current;
    if (v) v.currentTime = seekPreviewTime;
    resetHideTimer();
  }, [isSeeking, seekPreviewTime, resetHideTimer]);

  useEffect(() => {
    if (isSeeking) {
      window.addEventListener("mousemove", handleProgressMove);
      window.addEventListener("mouseup", handleProgressUp);
      window.addEventListener("touchmove", handleProgressMove);
      window.addEventListener("touchend", handleProgressUp);
    }
    return () => {
      window.removeEventListener("mousemove", handleProgressMove);
      window.removeEventListener("mouseup", handleProgressUp);
      window.removeEventListener("touchmove", handleProgressMove);
      window.removeEventListener("touchend", handleProgressUp);
    };
  }, [isSeeking, handleProgressMove, handleProgressUp]);

  const displayProgress = isSeeking ? (duration ? (seekPreviewTime / duration) * 100 : 0) : progress;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "#000",
        zIndex: 9999,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
      onClick={toggleControls}
    >
      <video
        ref={videoRef}
        src={videoUrl}
        style={{ width: "100%", height: "100%", objectFit: "contain" }}
        playsInline
        preload="metadata"
      />
      <video ref={previewVideoRef} src={videoUrl} style={{ display: "none" }} preload="metadata" />
      <canvas ref={canvasRef} style={{ display: "none" }} />

      {/* Top bar */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          padding: "8px 12px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          background: "linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)",
          opacity: showControls ? 1 : 0,
          transition: "opacity 0.3s",
          pointerEvents: showControls ? "auto" : "none",
          zIndex: 10,
        }}
      >
        <div
          onClick={(e) => { e.stopPropagation(); onClose(); }}
          style={{ cursor: "pointer", padding: 4 }}
        >
          <X size={20} color="white" />
        </div>
        <div style={{ color: "white", fontSize: "0.75rem", fontWeight: "bold", textAlign: "center", flex: 1, direction: "rtl", unicodeBidi: "plaintext" }}>
          {episodeName}
        </div>
      </div>

      {/* Center controls */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          display: "flex",
          alignItems: "center",
          gap: "40px",
          opacity: showControls ? 1 : 0,
          transition: "opacity 0.3s",
          pointerEvents: showControls ? "auto" : "none",
          zIndex: 10,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Skip back */}
        <div
          onClick={() => skip(-10)}
          style={{ cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", position: "relative" }}
        >
          <div style={{ position: "relative" }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M1 4v6h6" />
              <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
            </svg>
            <span style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", fontSize: "0.55rem", fontWeight: "bold", color: "white", marginTop: 1 }}>10</span>
          </div>
          {skipAnimation === "back" && (
            <span className="animate-skip" style={{ position: "absolute", top: -20, color: "white", fontSize: "0.75rem", fontWeight: "bold" }}>-10</span>
          )}
        </div>

        {/* Play/Pause */}
        <div onClick={togglePlay} style={{ cursor: "pointer" }}>
          {isPlaying ? (
            <svg width="48" height="48" viewBox="0 0 24 24" fill="white">
              <rect x="6" y="4" width="4" height="16" />
              <rect x="14" y="4" width="4" height="16" />
            </svg>
          ) : (
            <svg width="48" height="48" viewBox="0 0 24 24" fill="white">
              <polygon points="5,3 19,12 5,21" />
            </svg>
          )}
        </div>

        {/* Skip forward */}
        <div
          onClick={() => skip(10)}
          style={{ cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", position: "relative" }}
        >
          <div style={{ position: "relative" }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M23 4v6h-6" />
              <path d="M20.49 15a9 9 0 1 1-2.13-9.36L23 10" />
            </svg>
            <span style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", fontSize: "0.55rem", fontWeight: "bold", color: "white", marginTop: 1 }}>10</span>
          </div>
          {skipAnimation === "forward" && (
            <span className="animate-skip" style={{ position: "absolute", top: -20, color: "white", fontSize: "0.75rem", fontWeight: "bold" }}>+10</span>
          )}
        </div>
      </div>

      {/* Bottom progress */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: "12px 12px 8px",
          background: "linear-gradient(to top, rgba(0,0,0,0.7), transparent)",
          opacity: showControls ? 1 : 0,
          transition: "opacity 0.3s",
          pointerEvents: showControls ? "auto" : "none",
          zIndex: 10,
        }}
      >
        {/* Seek thumbnail preview */}
        {isSeeking && thumbnailUrl && (
          <div style={{ position: "absolute", bottom: 50, left: `${Math.max(10, Math.min(90, seekDotX))}%`, transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center" }}>
            <div style={{ borderRadius: 6, overflow: "hidden", border: "2px solid white" }}>
              <img src={thumbnailUrl} alt="" style={{ width: 160, height: 90, objectFit: "cover" }} />
            </div>
            <span style={{ color: "white", fontSize: "0.7rem", marginTop: 4, fontWeight: "bold" }}>{formatTime(seekPreviewTime)}</span>
          </div>
        )}
        {isSeeking && !thumbnailUrl && (
          <div style={{ position: "absolute", bottom: 50, left: `${Math.max(10, Math.min(90, seekDotX))}%`, transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center" }}>
            <div style={{ backgroundColor: "rgba(0,0,0,0.8)", borderRadius: 6, padding: "4px 10px" }}>
              <span style={{ color: "white", fontSize: "0.8rem", fontWeight: "bold" }}>{formatTime(seekPreviewTime)}</span>
            </div>
          </div>
        )}

        {/* Progress bar */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div
            ref={progressRef}
            style={{ flex: 1, height: 3, backgroundColor: "rgba(255,255,255,0.3)", borderRadius: 2, position: "relative", cursor: "pointer" }}
            onMouseDown={handleProgressDown}
            onTouchStart={handleProgressDown}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ width: `${displayProgress}%`, height: "100%", backgroundColor: "red", borderRadius: 2 }} />
            <div style={{ position: "absolute", top: "50%", left: `${displayProgress}%`, transform: "translate(-50%, -50%)", width: isSeeking ? 14 : 10, height: isSeeking ? 14 : 10, backgroundColor: "red", borderRadius: "50%", transition: "width 0.1s, height 0.1s" }} />
          </div>
          <span style={{ color: "white", fontSize: "0.7rem", fontWeight: "bold", minWidth: 36, textAlign: "center" }}>
            {formatTime(remaining > 0 ? remaining : 0)}
          </span>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
