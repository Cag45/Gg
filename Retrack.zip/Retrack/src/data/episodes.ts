import S1E1D from "../assets/S1E1D.png";
import S1E2D from "../assets/S1E2D.png";
import S1E3D from "../assets/S1E3D.png";
import S1E4D from "../assets/S1E4D.png";
import S1E5D from "../assets/S1E5D.png";
import S1E6D from "../assets/S1E6D.png";
import S1E7D from "../assets/S1E7D.png";
import S1E8D from "../assets/S1E8D.png";
import S1E9D from "../assets/S1E9D.png";
import S1E10D from "../assets/S1E10D.png";
import S2E1D from "../assets/S2E1D.png";
import S2E2D from "../assets/S2E2D.png";
import S2E3D from "../assets/S2E3D.png";
import S2E4D from "../assets/S2E4D.png";
import S2E5D from "../assets/S2E5D.png";
import S2E6D from "../assets/S2E6D.png";
import S2E7D from "../assets/S2E7D.png";
import S2E8D from "../assets/S2E8D.png";
import S2E9D from "../assets/S2E9D.png";
import S2E10D from "../assets/S2E10D.png";

export interface Episode {
  id: string;
  name: string;
  image: string;
  videoUrl: string;
  season: number;
}

const DEFAULT_VIDEO_URL = "https://dl.springsfern.in/dl/AAAAAdLvmkZQ8Y3VAAAeXw/OYqq6hMl3xHRI5yXvBGTHWxRBvaF10EHl4Iuzblnwtk";

export const episodes: Episode[] = [
  { id: "s1e1", name: "حلقة 1 - لنجلب كوكبًا!", image: S1E1D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e2", name: "حلقة 2 - من هنا، يا فتاة!", image: S1E2D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e3", name: "حلقة 3 - الدوران", image: S1E3D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e4", name: "حلقة 4 - من هو الكلب المهذّب؟", image: S1E4D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e5", name: "حلقة 5 - الهدوء!", image: S1E5D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e6", name: "حلقة 6 - التواصل", image: S1E6D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e7", name: "حلقة 7 - البقاء معنا", image: S1E7D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e8", name: "حلقة 8 - راقبني!", image: S1E8D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e9", name: "حلقة 9 - لنغادر!", image: S1E9D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s1e10", name: "حلقة 10 - توقّفي عن ذلك!", image: S1E10D, videoUrl: DEFAULT_VIDEO_URL, season: 1 },
  { id: "s2e1", name: "حلقة 1 - أساليب المجرّة", image: S2E1D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e2", name: "حلقة 2 - من هو معدّ الشاي؟", image: S2E2D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e3", name: "حلقة 3 - من يريد التفاوض؟", image: S2E3D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e4", name: "حلقة 4 - مخالب القدر", image: S2E4D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e5", name: "حلقة 5 - هويّة خاطئة", image: S2E5D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e6", name: "حلقة 6 - حان دور لوف", image: S2E6D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e7", name: "حلقة 7 - التجميد", image: S2E7D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e8", name: "حلقة 8 - برج جاربدج المرعب", image: S2E8D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e9", name: "حلقة 9 - بذرة الخير تطرح شرًا", image: S2E9D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
  { id: "s2e10", name: "حلقة 10 - العبث مع الشجرة الخطأ", image: S2E10D, videoUrl: DEFAULT_VIDEO_URL, season: 2 },
];

export const season1 = episodes.filter(e => e.season === 1);
export const season2 = episodes.filter(e => e.season === 2);
