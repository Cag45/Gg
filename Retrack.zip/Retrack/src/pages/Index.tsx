import { useState } from "react";
import "../App.css";
import bgImage from "../assets/bg.png";
import logoImage from "../assets/logo.png";
import { season1, season2, Episode } from "../data/episodes";
import VideoPlayer from "../components/VideoPlayer";

const Index = () => {
  const [activeEpisode, setActiveEpisode] = useState<Episode | null>(null);

  if (activeEpisode) {
    return (
      <VideoPlayer
        videoUrl={activeEpisode.videoUrl}
        episodeName={`موسم ${activeEpisode.season} | ${activeEpisode.name}`}
        onClose={() => setActiveEpisode(null)}
      />
    );
  }

  return (
    <div className="app-container">
      <section className="hero-section">
        <div className="hero-bg" style={{ backgroundImage: `url(${bgImage})` }} />
        <div className="hero-content">
          <h1 className="hero-title">كلاب في الفضاء</h1>
          <h2 className="hero-subtitle" dir="ltr">root ! حصريا</h2>
          <h2 className="hero-info">الموسم الأول والثاني - 20 حلقة كامله مدبلج بدون حذف</h2>
          <img src={logoImage} alt="Logo" className="hero-logo" />
        </div>
        <div className="mountains-divider">
          <div className="mountain-left" />
          <div className="mountain-right" />
        </div>
      </section>
      <div className="episodes-container">
        <div className="season-header">الموسم الأول</div>
        {season1.map((ep) => (
          <div key={ep.id} className="episode" onClick={() => setActiveEpisode(ep)}>
            <img src={ep.image} alt={ep.name} className="episode-image" />
            <div className="episode-bar">{ep.name}</div>
          </div>
        ))}
        <div className="season-header">الموسم الثاني</div>
        {season2.map((ep) => (
          <div key={ep.id} className="episode" onClick={() => setActiveEpisode(ep)}>
            <img src={ep.image} alt={ep.name} className="episode-image" />
            <div className="episode-bar">{ep.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Index;
